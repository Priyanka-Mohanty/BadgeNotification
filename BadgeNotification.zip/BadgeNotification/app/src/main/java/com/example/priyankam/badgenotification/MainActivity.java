package com.example.priyankam.badgenotification;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


   String STRING_ZERO = "0";
    String value;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText editInputText=(EditText)findViewById(R.id.input);
        ImageView imgNotification = (ImageView) findViewById(R.id.img_notification);
        final TextView textBadgeAlarmCount = (TextView) findViewById(R.id.badge_notification_count);


        editInputText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //set  badge Count
                value=editInputText.getText().toString().trim();
                if(value.equals(Integer.parseInt(STRING_ZERO))
                        ||value.isEmpty()){
                    textBadgeAlarmCount.setVisibility(View.GONE);
                } else {
                    textBadgeAlarmCount.setVisibility(View.VISIBLE);
                    textBadgeAlarmCount.setText(value);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }
}
